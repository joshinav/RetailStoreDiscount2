package com.util.naveen.abstractsimpl;

import com.util.naveen.abstracts.User;

public class Employee extends User {

	@Override
	public double calculateDis(double amt) {
		/*
		 * For Employee User : 30 % discount
		 */
		 double discountAmt= (30*amt)/100;
		 
	     return discountAmt;
	}
}
