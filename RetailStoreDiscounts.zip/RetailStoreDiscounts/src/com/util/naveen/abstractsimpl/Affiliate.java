package com.util.naveen.abstractsimpl;

import com.util.naveen.abstracts.User;

public class Affiliate extends User{

	@Override
	public double calculateDis(double amt) {
		
		/*
		 * For Affiliate User : 10 % discount
		 */
		 double discountAmt= (10*amt)/100;
		 
	     return discountAmt;
	}
}
