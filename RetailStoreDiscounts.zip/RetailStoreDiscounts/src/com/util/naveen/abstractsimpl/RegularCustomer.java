package com.util.naveen.abstractsimpl;

import com.util.naveen.abstracts.User;

public class RegularCustomer extends User {

	@Override
	public double calculateDis(double amt) {
		/*
		 * For Regular Customer from last 2 years : 5 % discount
		 */
		 double discountAmt= (5*amt)/100;
		 
	      return discountAmt;
		
	}
	
	

}
