package com.util.naveen.main;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/*
 * Main Class responsible to initiate Application.
 */
public class MainApplication {

	public static void main(String[] args) throws Exception{
		
		System.out.print("************************* APPLICATION USER NOTICE ******************************************** \n");
		System.out.println(" THIS APPLICATION WILL EXPECT TWO INPUTS FROM USER TO GENERATE BILL :");
		System.out.println(" 1. USER TYPE ONE OF THREE (EMPLOYEE,AFFILIATE,REGULAR_CUSTOMER) AND 2. MARKET PRICE FOR DISCOUNT CALCULATION : \n");
	   
		System.out.print("USER TYPE : ");
	    String userType = (new BufferedReader(new InputStreamReader(System.in))).readLine();

	    System.out.print("MARKET PRICE : ");
	    String marketPrice = (new BufferedReader(new InputStreamReader(System.in))).readLine();
	    double amt = Double.parseDouble(marketPrice);
		
		/*
		 * Request an Singleton Class to avoid Multiple instance creation:
		 */
		try{
			RetailDiscountInitiator.getInstance().initiate(userType,amt);
		}
		catch(Exception e){
			System.out.println("Exception Found");
		}
	}
}
