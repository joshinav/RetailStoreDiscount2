package com.util.naveen.main;

import com.util.naveen.main.calculatorUtil.DiscountCalculatorUtil;

/*
 * Utility created as Singleton to avoid Multiple Instance Creation:
 */
public class RetailDiscountInitiator {
	
	private static RetailDiscountInitiator instance = null;
	protected RetailDiscountInitiator(){
		
	}
	
	public static RetailDiscountInitiator getInstance(){
		if(instance == null){
			instance = new RetailDiscountInitiator();
		}
		return instance;
	}
	
	public static void initiate(String UsrType, double amt){
		
		String msg = DiscountCalculatorUtil.eligibleDiscount(UsrType,amt);
	}

}
