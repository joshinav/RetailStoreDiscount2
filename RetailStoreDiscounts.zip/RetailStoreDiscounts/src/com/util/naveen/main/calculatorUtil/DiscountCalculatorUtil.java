package com.util.naveen.main.calculatorUtil;

import com.util.naveen.abstracts.User;
import com.util.naveen.abstractsimpl.Affiliate;
import com.util.naveen.abstractsimpl.Employee;
import com.util.naveen.abstractsimpl.RegularCustomer;

/*
 * Utility designed on Abstract Pattern to calculate Discounts:
 */
public class DiscountCalculatorUtil {

	public static String eligibleDiscount(String UsrType, double amt){
	
	if(UsrType.equalsIgnoreCase("EMPLOYEE")){
		User u1 = new Employee();
		double disAmt = u1.calculateDis(amt);
		printFinalReport(amt,disAmt,"EMPLOYEE");
	}
	else if(UsrType.equalsIgnoreCase("AFFILIATE")){
		User u1 = new Affiliate();
		double disAmt = u1.calculateDis(amt);
		printFinalReport(amt,disAmt,"AFFILIATE");
	}
	else if(UsrType.equalsIgnoreCase("REGULAR_CUSTOMER")){
		User u1 = new RegularCustomer();
		double disAmt = u1.calculateDis(amt);
		printFinalReport(amt,disAmt,"REGULAR CUSTOMER");
	}
	else {
		return null;
	}
	
	return " FINAL REPORT ";
}
	
	public static void printFinalReport(double marketAmt, double disAmt, String userType){
		
		double finalPrice = marketAmt - disAmt;
		
		System.out.println("************************************************************");
		System.out.println(" BILL INVOICE - ");
		System.out.println(" USER TYPE    	: "+userType);
		System.out.println(" MARKET PRICE 	: "+marketAmt);
		System.out.println(" DISCOUNT AMOUNT : "+disAmt);
		System.out.println(" PRICE AFTER DISCOUNT : "+ finalPrice);
		System.out.println("************************************************************");
	}
	
}
