package com.util.naveen.abstracts;

public abstract class User {

	public abstract double calculateDis(double amt);
}
