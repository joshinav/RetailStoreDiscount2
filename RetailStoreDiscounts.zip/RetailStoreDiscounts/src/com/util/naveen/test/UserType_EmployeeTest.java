package com.util.naveen.test;

import org.junit.Test;

import com.util.naveen.main.calculatorUtil.DiscountCalculatorUtil;

public class UserType_EmployeeTest {

	@Test
	public void test() {
		String usrType = "EMPLOYEE";
		double amt = 500;
		assertTrue(DiscountCalculatorUtil.eligibleDiscount(usrType, amt));
	}

	private void assertTrue(String eligibleDiscount) {
		// TODO Auto-generated method stub
		
	}
}
